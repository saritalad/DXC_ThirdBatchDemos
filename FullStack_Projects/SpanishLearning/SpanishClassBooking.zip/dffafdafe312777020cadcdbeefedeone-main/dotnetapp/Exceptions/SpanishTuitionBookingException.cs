using System;

namespace dotnetapp.Exceptions
{
public class SpanishTuitionBookingException : Exception
{
    public SpanishTuitionBookingException(string message) : base(message)
    {
    }
}
}