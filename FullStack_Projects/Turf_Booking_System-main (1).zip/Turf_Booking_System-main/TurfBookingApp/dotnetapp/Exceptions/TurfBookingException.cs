using System;

namespace dotnetapp.Exceptions
{

public class TurfBookingException : Exception
{
    public TurfBookingException(string message) : base(message)
    {
    }
}
}

